import os
import unittest
from subprocess import Popen, PIPE

from ai_flow.common.process_utils import get_all_children_pids


class TestProcessUtil(unittest.TestCase):

    def test_get_children(self):
        hh = []
        for i in range(5):
            submitted_process = Popen(
                args="sleep 5",
                shell=True,
                stdout=PIPE,
                stderr=PIPE
            )
            hh.append(submitted_process)
        res = get_all_children_pids(os.getpid())
        print(res)
        # self.assertEqual(5, len(res))
        for h in hh:
            h.wait()


if __name__ == '__main__':
    unittest.main()
