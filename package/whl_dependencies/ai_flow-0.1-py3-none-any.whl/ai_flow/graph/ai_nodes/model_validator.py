from typing import Text, List
from ai_flow.meta.artifact_meta import ArtifactMeta
from ai_flow.meta.model_meta import ModelMeta, ModelVersionMeta
from ai_flow.common.properties import ExecuteProperties
from ai_flow.executor.executor import BaseExecutor
from ai_flow.graph.ai_nodes.executable import ExecutableNode
from ai_flow.graph.channel import NoneChannel, Channel


class ModelValidator(ExecutableNode):

    def __init__(self,
                 model: ModelMeta,
                 executor: BaseExecutor,
                 model_version_meta: ModelVersionMeta = None,
                 base_model_version_meta: ModelVersionMeta = None,
                 properties: ExecuteProperties = None,
                 name: Text = None,
                 instance_id: Text = None,
                 output_num: int = 0) -> None:
        super().__init__(executor=executor,
                         properties=properties,
                         name=name,
                         instance_id=instance_id,
                         output_num=output_num)
        self.model = model
        self.model_version_meta = model_version_meta
        self.base_model_version_meta = base_model_version_meta

