import pika


def connect(uri):
    connection = pika.BlockingConnection(pika.ConnectionParameters(uri))
    return connection


def create_channel(conn: pika.BaseConnection, channel_num=None):
    return conn.channel(channel_number=channel_num)


def declare(channel, queue):
    channel.queue_declare(queue=queue)


def close(connection):
    connection.close()


def send_message(channel, routing_key,  message):
    channel.basic_publish(exchange='',
                          routing_key=routing_key,
                          body=message)


def receive_message(channel, queue)->bytes:
    c = channel.basic_get(queue=queue)
    channel.basic_ack(delivery_tag=c[0].delivery_tag)
    return c[2]
