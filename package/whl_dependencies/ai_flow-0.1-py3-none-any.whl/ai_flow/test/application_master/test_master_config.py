import unittest

from ai_flow.application_master.master_config import MasterConfig, DBType


class TestConfiguration(unittest.TestCase):

    def test_dump_load_configuration(self):
        config = MasterConfig()
        config.set_db_uri(db_type=DBType.SQLITE, uri="sqlite:///sql.db")
        self.assertEqual('sql.db', config.get_sql_lite_db_file())


if __name__ == '__main__':
    unittest.main()
