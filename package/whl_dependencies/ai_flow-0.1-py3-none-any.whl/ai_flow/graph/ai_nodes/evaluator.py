from typing import Text, List

from ai_flow.meta.model_meta import ModelMeta
from ai_flow.common.properties import ExecuteProperties
from ai_flow.graph.ai_nodes.predictor import Predictor
from ai_flow.meta.artifact_meta import ArtifactMeta
from ai_flow.executor.executor import BaseExecutor
from ai_flow.graph.channel import NoneChannel, Channel


class Evaluator(Predictor):

    def __init__(self,
                 model: ModelMeta,
                 executor: BaseExecutor,
                 properties: ExecuteProperties = None,
                 name: Text = None,
                 instance_id=None,
                 output_num=0) -> None:
        super().__init__(model=model, executor=executor, properties=properties, name=name, instance_id=instance_id,
                         output_num=output_num)
