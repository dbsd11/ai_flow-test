import threading
import time
import traceback
from subprocess import Popen
from typing import Text, Any, Dict
from ai_flow.deployer.listener import JobStatusEvent
from ai_flow.meta.job_meta import State
from ai_flow.plugins.platform import AbstractPlatform, AbstractJobHandler, AbstractJobStatusListener


class LocalJobHandler(AbstractJobHandler):

    def __init__(self, job_instance_id: Text, job_uuid: int, workflow_id: int, process_object: Any = None) -> None:
        super().__init__(job_instance_id, job_uuid, workflow_id)
        self.platform = LocalPlatform.platform()
        self.process_object = process_object


class LocalPlatform(AbstractPlatform):
    @staticmethod
    def job_status_listener() -> type(AbstractJobStatusListener):
        return LocalJobStatusListener

    @staticmethod
    def platform() -> Text:
        return 'local'


class LocalJobStatusListener(AbstractJobStatusListener):
    def __init__(self, time_interval=2) -> None:
        super().__init__(platform=LocalPlatform.platform())
        self.time_interval = time_interval
        self.job_handles: Dict[int, LocalJobHandler] = {}
        # key job uuid, value State
        self.status_map = {}
        self.running = True
        self.lock = threading.Lock()

    def listen(self):
        while self.running:
            self.lock.acquire()
            try:
                key_set = set()
                for handle in self.job_handles.values():
                    if isinstance(handle.process_object, Popen):
                        if handle.process_object.poll() is None:
                            status = State.RUNNING
                        else:
                            if 0 == handle.process_object.returncode:
                                status = State.FINISHED
                            elif -9 == handle.process_object.returncode:
                                print("returncode {}".format(handle.process_object.returncode))
                                status = State.FAILED
                            else:
                                print("returncode {}".format(handle.process_object.returncode))
                                status = State.FAILED
                    else:
                        raise Exception("not support exec handle " + str(handle))

                    # kill job do not send message
                    if status is None:
                        print("kill job {}".format(handle.job_instance_id))
                        if handle.job_uuid in self.status_map:
                            del self.status_map[handle.job_uuid]
                        time.sleep(self.time_interval)
                        continue
                    # send event
                    if handle.job_uuid in self.status_map:
                        ss = self.status_map[handle.job_uuid]
                        if ss != status:
                            event = JobStatusEvent(workflow_id=handle.workflow_id,
                                                   job_id=handle.job_instance_id,
                                                   status=status.value)
                            self.status_map[handle.job_uuid] = status
                            self.message_queue.send(event)
                    else:
                        event = JobStatusEvent(workflow_id=handle.workflow_id,
                                               job_id=handle.job_instance_id,
                                               status=State.RUNNING.value)
                        self.status_map[handle.job_uuid] = State.RUNNING
                        self.message_queue.send(event)
                        if status != State.RUNNING:
                            event = JobStatusEvent(workflow_id=handle.workflow_id,
                                                   job_id=handle.job_instance_id,
                                                   status=status.value)
                            self.status_map[handle.job_uuid] = status
                            self.message_queue.send(event)

                # clean up status_map
                for k, v in self.status_map.items():
                    if v == State.FINISHED or v == State.FAILED:
                        key_set.add(k)
                for k in key_set:
                    if k in self.status_map:
                        del self.status_map[k]
            finally:
                self.lock.release()
            time.sleep(self.time_interval)

    def run(self):
        try:
            self.listen()
        except Exception as e:
            print(e)
            traceback.print_exc()

    def start_listen(self):
        self.setDaemon(daemonic=True)
        self.setName(self.platform + "_listener")
        self.start()

    def stop_listen(self):
        self.running = False
        self.join()

    def register_job_listening(self, job_handler: LocalJobHandler):
        self.lock.acquire()
        try:
            self.job_handles[job_handler.job_uuid] = job_handler
        finally:
            self.lock.release()

    def stop_job_listening(self, job_uuid: int):
        self.lock.acquire()
        try:
            if job_uuid in self.job_handles:
                del self.job_handles[job_uuid]
            if job_uuid in self.status_map:
                del self.status_map[job_uuid]
        finally:
            self.lock.release()
