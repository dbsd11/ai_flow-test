import threading
from threading import Thread
from typing import List, Dict, Text
from typing import Set, Tuple
from ai_flow.common.message_queue import MessageQueue
from ai_flow.common.registry import BaseRegistry
from ai_flow.notification.entity.notification import Notification
from ai_flow.rest_endpoint.service.client.notification_client import Watcher
from ai_flow.workflow.job_handler import BaseJobHandler


class SignalEvent(object):

    def __init__(self, name, key, value) -> None:
        self.name = name
        self.key = key
        self.value = value


class SignalWatcher(Watcher):
    def __init__(self, message_queue: MessageQueue):
        super().__init__()
        self.message_queue = message_queue

    def process(self, listener_name, notifications: List[Notification]):
        for notification in notifications:
            event = SignalEvent(name=listener_name, key=notification.key, value=notification.value)
            self.message_queue.send(event)


class SignalListener(object):
    def __init__(self, client, watcher) -> None:
        self.client = client
        self.listen_record: Set[Tuple] = set()
        self.watcher = watcher
        self.lock = threading.Lock()

    def start_listen(self, listener_name, event_key, event_version=None):
        self.client.start_listen_notification(listener_name=listener_name,
                                              key=event_key, version=event_version, watcher=self.watcher)
        self.lock.acquire()
        try:
            self.listen_record.add((listener_name, event_key))
        finally:
            self.lock.release()

    def stop_listen(self, listener_name, event_key):
        self.client.stop_listen_notification(listener_name=listener_name, key=event_key)
        self.lock.acquire()
        try:
            self.listen_record.discard((listener_name, event_key))
        finally:
            self.lock.release()

    def stop_listen_all(self):
        self.lock.acquire()
        try:
            for i in self.listen_record:
                self.client.stop_listen_notification(listener_name=i[0], key=i[1])
            self.listen_record.clear()
        finally:
            self.lock.release()


class JobStatusEvent(object):

    def __init__(self, workflow_id: int, job_id: Text, status: Text) -> None:
        self.workflow_id = workflow_id
        self.job_id = job_id
        self.status = status


class BaseJobStatusListener(Thread):

    def __init__(self, platform) -> None:
        """

        :param platform:
        """
        super().__init__()
        self.platform = platform
        self.message_queue: MessageQueue = None

    def set_message_queue(self, message_queue: MessageQueue):
        self.message_queue = message_queue

    def start_listen(self):
        """
        """
        pass

    def stop_listen(self):
        pass

    def register_job_listening(self, job_handler: BaseJobHandler):
        """

        :param job_handler:
        """
        pass

    def stop_job_listening(self, job_id: int):
        """

        :param job_id:
        """
        pass


class JobStatusListenerManager(BaseRegistry):
    def __init__(self):
        super().__init__()
        self.object_dict: Dict[Text, BaseJobStatusListener] = {}
        self.listener_threads: Dict[Text, Thread] = {}

    def set_message_queue(self, message_queue: MessageQueue):
        for key in self.object_dict.keys():
            listener: BaseJobStatusListener = self.get_object(key)
            listener.set_message_queue(message_queue)

    def start_all_listeners(self):
        for key in self.object_dict.keys():
            listener: BaseJobStatusListener = self.get_object(key)
            listener.start_listen()
            self.listener_threads[key] = listener

    def stop_all_listeners(self):
        for key in self.object_dict.keys():
            listener: BaseJobStatusListener = self.get_object(key)
            listener.stop_listen()


_default_job_status_manager = JobStatusListenerManager()


def register_job_status_listener(listener: BaseJobStatusListener):
    _default_job_status_manager.register(listener.platform, listener)


class MessageDispatcher(Thread):
    def __init__(self, main_message_queue: MessageQueue) -> None:
        super().__init__()
        self.main_message_queue = main_message_queue
        # key: workflow_id value: scheduler message_queue
        self.message_queue_map: Dict[int, MessageQueue] = {}
        # key: signal_key
        self.signal_key_map: Dict[Text, Set[int]] = {}
        self.running_flag = True
        self.setDaemon(True)
        self.setName("message-dispatcher")
        self.mq_lock = threading.Lock()
        self.sg_lock = threading.Lock()

    def register_message_queue(self, workflow_id: int, mq: MessageQueue):
        self.mq_lock.acquire()
        try:
            self.message_queue_map[workflow_id] = mq
        finally:
            self.mq_lock.release()

    def deregister_message_queue(self, workflow_id: int):
        self.mq_lock.acquire()
        try:
            if workflow_id in self.message_queue_map:
                del self.message_queue_map[workflow_id]
        finally:
            self.mq_lock.release()

    def listen_signal_key(self, workflow_id: int, event_key: Text):
        self.sg_lock.acquire()
        try:
            if event_key not in self.signal_key_map:
                self.signal_key_map[event_key] = set()
            self.signal_key_map[event_key].add(workflow_id)
        finally:
            self.sg_lock.release()

    def release_signal_key(self, workflow_id: int, event_key: Text):
        self.sg_lock.acquire()
        try:
            if event_key in self.signal_key_map:
                self.signal_key_map[event_key].discard(workflow_id)
                if 0 == len(self.signal_key_map[event_key]):
                    del self.signal_key_map[event_key]
        finally:
            self.sg_lock.release()

    def run(self):
        while self.running_flag:
            event = self.main_message_queue.get_with_timeout(timeout=2)
            if event is None:
                # no event
                continue
            else:
                self.mq_lock.acquire()
                try:
                    if isinstance(event, SignalEvent):
                        signal_key = event.key
                        self.sg_lock.acquire()
                        try:
                            if signal_key in self.signal_key_map:
                                for w_id in self.signal_key_map[signal_key]:
                                    if w_id in self.message_queue_map:
                                        self.message_queue_map[w_id].send(event)
                        finally:
                            self.sg_lock.release()
                    elif isinstance(event, JobStatusEvent):
                        workflow_id = event.workflow_id
                        if workflow_id in self.message_queue_map:
                            self.message_queue_map[workflow_id].send(event)
                finally:
                    self.mq_lock.release()

    def stop_dispatcher(self):
        self.running_flag = False
        self.join()


class ListenerManager(object):
    def __init__(self, client):
        self.message_queue = MessageQueue()
        watcher = SignalWatcher(self.message_queue)
        self.signal_listener: SignalListener = SignalListener(client=client, watcher=watcher)
        self.job_status_listener_manager = _default_job_status_manager
        self.job_status_listener_manager.set_message_queue(self.message_queue)
        # key workflow_id; value scheduler message queue
        self.message_dispatcher: MessageDispatcher = MessageDispatcher(main_message_queue=self.message_queue)

    def start_dispatcher(self):
        self.message_dispatcher.start()

    def stop_dispatcher(self):
        self.message_dispatcher.stop_dispatcher()
        if self.message_dispatcher.is_alive():
            self.message_dispatcher.join()

    def get_event(self):
        return self.message_queue.get()

    def send_event(self, event):
        self.message_queue.send(event)

    def register_message_queue(self, workflow_id: int, mq: MessageQueue):
        self.message_dispatcher.register_message_queue(workflow_id, mq)

    def deregister_message_queue(self, workflow_id: int):
        self.message_dispatcher.deregister_message_queue(workflow_id)

    def start_job_status_listener(self):
        self.job_status_listener_manager.start_all_listeners()

    def stop_job_status_listener(self):
        self.job_status_listener_manager.stop_all_listeners()

    def register_job_handler_listening(self, job_handler: BaseJobHandler):
        job_listener: BaseJobStatusListener = self.job_status_listener_manager.get_object(job_handler.platform)
        job_listener.register_job_listening(job_handler)

    def stop_job_handler_listening(self, job_handler: BaseJobHandler):
        job_listener: BaseJobStatusListener = self.job_status_listener_manager.get_object(job_handler.platform)
        job_listener.stop_job_listening(job_handler.job_uuid)

    def start_listen_signal(self, listener_name, event_key, event_version=None):
        self.signal_listener.start_listen(listener_name=listener_name, event_key=event_key, event_version=event_version)

    def stop_listen_signal(self, listener_name, event_key):
        self.signal_listener.stop_listen(listener_name=listener_name, event_key=event_key)

    def stop_listen_all_signal(self):
        self.signal_listener.stop_listen_all()
