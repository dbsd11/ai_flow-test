
class BaseClient(object):
    def __init__(self, *args, **kwargs):
        pass
