from ai_flow.graph.ai_nodes.executable import ExecutableNode


class Transformer(ExecutableNode):
    pass
