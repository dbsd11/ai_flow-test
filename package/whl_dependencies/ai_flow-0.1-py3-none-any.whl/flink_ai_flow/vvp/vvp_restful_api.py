import requests
import json
import os
from ai_flow.common import json_utils

default_flink_image_info = {
    "flinkVersion": "1.10",
    "flinkImageRegistry": "registry-vpc.cn-beijing.aliyuncs.com/vvp-prod",
    "flinkImageRepository": "flink",
    "flinkImageTag": "1.10.0-stream1-scala_2.11"
}

default_resources = {
    "jobmanager": {
        "cpu": 1.0,
        "memory": "1G"
    },
    "taskmanager": {
        "cpu": 1.0,
        "memory": "2G"
    }
}

default_flink_config = {
    "metrics.reporter.promgatewayappmgr.groupingKey": "deploymentName={{deploymentName}};deploymentId={{deploymentId}};jobId={{jobId}}",
    "metrics.reporter.promgatewayappmgr.jobName": "{{deploymentName}}",
    "metrics.reporter.promgatewayappmgr.port": "9091",
    "metrics.reporters": "promgatewayappmgr",
    "metrics.reporter.promgatewayappmgr.class": "org.apache.flink.metrics.prometheus.PrometheusPushGatewayReporter",
    "metrics.reporter.promgatewayappmgr.host": "vvp-outh214uy7-pushgateway.vvp-outh214uy7"
}

default_logging = {
    "loggingProfile": "default",
    "log4jLoggers": {
        "": "INFO"
    }
}


class VVPRestful(json_utils.Jsonable):
    def __init__(self, base_url, namespace, token) -> None:
        self.base_url = base_url
        self.namespace = namespace
        if token is None:
            self.headers = {}
        else:
            self.headers = {'Authorization': '{} {}'.format('Bearer', token)}

    def up_load_artifact(self, artifact_path) -> str:
        url = self.base_url + "/artifacts/v1/namespaces/{}/artifacts:upload".format(self.namespace)
        file_name = os.path.basename(artifact_path)
        json_content = {
            "artifact": {
                "filename": file_name,
                "content": "",
            }
        }
        files = {'file': open(artifact_path, 'rb')}
        response = requests.post(url=url, json=json_content, files=files, headers=self.headers)
        return json.loads(response.content)['artifact']['uri']

    def list_artifacts(self) -> list:
        url = self.base_url + "/artifacts/v1/namespaces/{}/artifacts:list".format(self.namespace)
        response = requests.get(url=url, headers=self.headers)
        return json.loads(response.content)['artifacts']

    def list_deployment_targets(self):
        url = self.base_url + "/api/v1/namespaces/{}/deployment-targets".format(self.namespace)
        response = requests.get(url=url, headers=self.headers)
        return json.loads(response.content)['items']

    def get_deployment_target_id(self) -> str:
        targets = self.list_deployment_targets()
        for target in targets:
            if target['metadata']['namespace'] == self.namespace:
                return target['metadata']['id']
        return ''

    def create_deployment(self,
                          name,
                          jar_uri,
                          entry_class,
                          main_args="",
                          flink_image_info=default_flink_image_info,
                          parallelism=1,
                          resources=default_resources,
                          flink_config=default_flink_config,
                          logging=default_logging):
        url = self.base_url + "/api/v1/namespaces/{}/deployments".format(self.namespace)
        target_id = self.get_deployment_target_id()
        json_content = {
            "kind": "Deployment",
            "apiVersion": "v1",
            "metadata": {
                "name": name,
                "namespace": self.namespace,
            },
            "spec": {
                "state": "RUNNING",
                "upgradeStrategy": {
                    "kind": "STATEFUL"
                },
                "restoreStrategy": {
                    "kind": "LATEST_STATE",
                    "allowNonRestoredState": False
                },
                "deploymentTargetId": target_id,
                "maxSavepointCreationAttempts": 4,
                "maxJobCreationAttempts": 4,
                "template": {
                    "metadata": {
                        "annotations": {
                            "flink.security.ssl.enabled": "false",
                            "flink.queryable-state.enabled": "false"
                        }
                    },
                    "spec": {
                        "artifact": {
                            "kind": "JAR",
                            "jarUri": jar_uri,
                            "entryClass": entry_class,
                            "mainArgs": main_args,
                            "flinkVersion": flink_image_info['flinkVersion'],
                            "flinkImageRegistry": flink_image_info["flinkImageRegistry"],
                            "flinkImageRepository": flink_image_info["flinkImageRepository"],
                            "flinkImageTag": flink_image_info["flinkImageTag"]
                        },
                        "parallelism": parallelism,
                        "resources": resources,
                        "flinkConfiguration": flink_config,
                        "logging": logging
                    }
                }
            }
        }
        response = requests.post(url=url, json=json_content, headers=self.headers)
        result = json.loads(response.content)
        return result['metadata']['id'], result

    def start_deployment(self, deployment_id) -> bool:
        url = self.base_url + "/api/v1/namespaces/{}/deployments/{}".format(self.namespace, deployment_id)
        json_content = {
            "spec": {
                "state": "RUNNING"
            }
        }
        headers = {'Content-Type': 'application/json'}
        headers.update(self.headers)
        response = requests.patch(url=url, data=json.dumps(json_content), headers=headers)
        if 200 == response.status_code:
            return True
        else:
            return False

    def stop_deployment(self, deployment_id) -> bool:
        url = self.base_url + "/api/v1/namespaces/{}/deployments/{}".format(self.namespace, deployment_id)
        json_content = {
            "spec": {
                "state": "CANCELLED",
            }
        }
        headers = {'Content-Type': 'application/json'}
        headers.update(self.headers)
        response = requests.patch(url=url, data=json.dumps(json_content), headers=headers)
        if 200 == response.status_code:
            return True
        else:
            return False

    def delete_deployment(self, deployment_id) -> bool:
        url = self.base_url + "/api/v1/namespaces/{}/deployments/{}".format(self.namespace, deployment_id)
        response = requests.delete(url=url, headers=self.headers)
        if 200 == response.status_code:
            return True
        else:
            return False

    def get_deployment_events(self, deployment_id):
        url = self.base_url + "/api/v1/namespaces/{}/events".format(self.namespace)
        response = requests.get(url=url, params={'deploymentId': deployment_id}, headers=self.headers)
        return json.loads(response.content)

    def get_job_events(self, job_id):
        url = self.base_url + "/api/v1/namespaces/{}/events".format(self.namespace)
        response = requests.get(url=url, params={'jobId': job_id}, headers=self.headers)
        return json.loads(response.content)

    def get_job_ids(self, deployment_id) -> list:
        url = self.base_url + "/api/v1/namespaces/{}/jobs".format(self.namespace)
        response = requests.get(url=url, params={'deploymentId': deployment_id}, headers=self.headers)
        jobs = json.loads(response.content)['items']
        job_id_list = []
        for job in jobs:
            job_id_list.append(job['metadata']['id'])
        return job_id_list
