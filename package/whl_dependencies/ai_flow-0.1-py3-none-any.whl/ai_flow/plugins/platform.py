from typing import Text
from ai_flow.common.json_utils import Jsonable
from ai_flow.deployer.listener import register_job_status_listener, BaseJobStatusListener
from ai_flow.workflow.job_handler import BaseJobHandler

AbstractJobHandler = BaseJobHandler
AbstractJobStatusListener = BaseJobStatusListener


class AbstractPlatform(Jsonable):
    """
    ai flow job must run on one platform, such as local k8s etc.
    """

    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    def platform() -> Text:
        """
        :return platform name:
        """
        raise NotImplementedError("not implement platform")

    @staticmethod
    def job_status_listener() -> type(AbstractJobStatusListener):
        """
        :return AbstractJobStatusListener class:
        """
        raise NotImplementedError("not implement AbstractJobStatusListener")


def register_platform(platform: type(AbstractPlatform)):
    register_job_status_listener(platform.job_status_listener()())
