import ai_flow as af
from ai_flow import ExecuteArgs, Properties
from ai_flow.application_master.master import AIFlowMaster
from ai_flow.common.json_utils import dumps
import flink_ai_flow as faf
import test_util


def run_flink_predict_job():
    example_1 = af.create_example(name="example_1",
                                  support_type=af.ExampleSupportType.EXAMPLE_BOTH,
                                  batch_uri="../../tmp/test1.csv",
                                  stream_uri="../../tmp/test1.csv",
                                  data_format="csv")

    example_2 = af.create_example(name="example_2",
                                  support_type=af.ExampleSupportType.EXAMPLE_BOTH,
                                  batch_uri="../../tmp/test2.csv",
                                  stream_uri="../../tmp/test2.csv",
                                  data_format="csv")
    flink_config = faf.LocalFlinkJobConfig()
    flink_config.flink_home = ''
    with af.config(flink_config):
        batch_args_1: Properties = {}
        ddl = """CREATE TABLE input_table (a STRING, b STRING, c STRING) WITH ('connector' = 'filesystem',
                        'path' = 'INPUT',
                        'format' = 'csv'
                        )"""
        table_name = "input_table"
        batch_args_1['ddl'] = ddl
        batch_args_1['table_name'] = table_name

        stream_args_1 = batch_args_1

        input_example = af.read_example(example_info=example_1,
                                        exec_args=ExecuteArgs(
                                            batch_properties=batch_args_1,
                                            stream_properties=stream_args_1)
                                        )
        model_meta = af.ModelMeta(name="test", model_type="saved_model")

        exec_args: ExecuteArgs = ExecuteArgs()
        exec_args.common_properties = {'a': 'a'}
        train = af.train(input_data_list=[input_example],
                         model_info=model_meta,
                         base_model_info=None,
                         exec_args=exec_args,
                         executor=faf.flink_executor.FlinkJavaExecutor(
                             java_class="com.apache.flink.ai.flow.TestTrain"),
                         name='aa')

    workflow = af.compile_workflow(project_path=test_util.get_project_path())
    print(dumps(list(workflow.jobs.values())[0]))


if __name__ == '__main__':
    config_file = test_util.get_master_config_file()
    master = AIFlowMaster(
        config_file=config_file)
    master.start()
    test_util.set_project_config(__file__)
    run_flink_predict_job()
    master.stop()
