from python_ai_flow.python_job_common import BaseExampleComponent
from python_ai_flow.user_define_funcs import Executor, ExampleExecutor
from ai_flow.common.serialization_utils import deserialize


class UDFExampleComponent(BaseExampleComponent):
    def batch_executor(self) -> Executor:
        executor: ExampleExecutor = deserialize(self.example_node.executor.python_object)
        executor.example_meta = self.example_meta
        return executor

    def stream_executor(self) -> Executor:
        executor: ExampleExecutor = deserialize(self.example_node.executor.python_object)
        executor.example_meta = self.example_meta
        return executor

