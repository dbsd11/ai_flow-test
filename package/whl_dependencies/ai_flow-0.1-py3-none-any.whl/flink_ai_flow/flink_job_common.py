from ai_flow.common import serialization_utils
from ai_flow.plugins.job_plugin import AbstractJobConfig
from typing import Dict, Text
from ai_flow.plugins.language import LanguageType
from flink_ai_flow.pyflink.user_define_executor import TableEnvCreator
from flink_ai_flow.flink_engine import FlinkEngine


class FlinkJobConfig(AbstractJobConfig):
    @staticmethod
    def from_dict(data: Dict, config) -> object:
        AbstractJobConfig.from_dict(data, config)
        config.flink_home = data['flink_home']
        config.jm_host_port = data.get('jm_host_port', 'localhost:8081')
        config.class_path = data.get('class_path')
        config.py_entry_file = data.get('py_entry_file')
        config.py_files = data.get('py_files')
        config.py_module = data.get('py_module')
        config.jar_path = data.get('jar_path')
        config.language_type: LanguageType = data.get('language_type')
        config.flink_conf = data.get('flink_conf')
        config.image = data.get('ai_flow_worker_image')
        return config

    def __init__(self, platform: Text):
        super().__init__(platform=platform, engine=FlinkEngine.engine())
        self.flink_home = None
        self.jm_host_port = 'localhost:8081'
        self.class_path = None
        self.py_entry_file = None
        self.py_files = None
        self.py_module = None
        self.jar_path = None
        self.args = []
        self.language_type: LanguageType = LanguageType.JAVA
        self.table_env_create_func: bytes = serialization_utils.serialize(TableEnvCreator())

    def set_table_env_create_func(self, func):
        self.table_env_create_func = serialization_utils.serialize(func)

    def get_table_env_create_func(self):
        return serialization_utils.deserialize(self.table_env_create_func)
