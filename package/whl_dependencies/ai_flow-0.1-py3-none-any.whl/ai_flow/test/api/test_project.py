import sys
import time
import unittest

import ai_flow as af
from ai_flow import AIFlowMaster
from ai_flow.executor.executor import CmdExecutor
from ai_flow.graph.edge import SignalAction, SignalValueCondition, SignalCondition, SignalLife
from ai_flow.test import test_util
from ai_flow.workflow.job_config import PeriodicConfig


class TestProject(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config_file = test_util.get_master_config_file()
        cls.master = AIFlowMaster(config_file=config_file)
        cls.master.start()
        test_util.set_project_config(__file__)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.master.stop()

    def setUp(self):
        af.default_graph().clear_graph()

    def tearDown(self):
        TestProject.master._clear_db()

    @staticmethod
    def build_ai_graph(sleep_time: int):
        with af.engine('cmd_line'):
            p_list = []
            for i in range(3):
                p = af.user_define_operation(
                    executor=CmdExecutor(cmd_line="echo 'hello_{}' && sleep {}".format(i, sleep_time)))
                p_list.append(p)
            af.stop_before_control_dependency(p_list[0], p_list[1])
            af.stop_before_control_dependency(p_list[0], p_list[2])

    def test_run_project(self):
        print(sys._getframe().f_code.co_name)
        TestProject.build_ai_graph(1)
        workflow_id = af.submit_ai_flow()
        res = af.wait_workflow_execution_finished(workflow_id)
        self.assertEqual(0, res)

    def test_stop_workflow_execution(self):
        print(sys._getframe().f_code.co_name)
        TestProject.build_ai_graph(5)
        exec_id = af.submit_ai_flow()
        self.assertGreater(exec_id, 0, "workflow execution id must greater than 0")
        res = af.stop_execution_by_id(exec_id)
        self.assertEqual(0, res[0])
        time.sleep(3)

    def test_stream_with_external_trigger(self):
        print(sys._getframe().f_code.co_name)
        trigger = af.external_trigger(name='stream_trigger')
        job_config = af.BaseJobConfig('local', 'cmd_line')
        job_config.job_name = 'test_cmd'
        with af.config(job_config):
            cmd_executor = af.user_define_operation(output_num=0,
                                                    executor=CmdExecutor(
                                                        cmd_line="echo 'hello world' && sleep {}".format(1)))
        af.user_define_control_dependency(src=cmd_executor, dependency=trigger, signal_key='key',
                                          signal_value='value', signal_name='name', condition=SignalCondition.NECESSARY
                                          , action=SignalAction.START, life=SignalLife.ONCE,
                                          value_condition=SignalValueCondition.EQUAL)
        workflow_id = af.submit_ai_flow()
        af.get_ai_flow_client().update_notification('key', 'value')
        time.sleep(5)
        af.get_ai_flow_client().update_notification('key', 'value')
        time.sleep(10)
        af.stop_execution_by_id(workflow_id)
        res = af.get_ai_flow_client().list_job(5, 0)
        self.assertEqual(3, len(res))

    def test_user_define_control_dependency(self):
        print(sys._getframe().f_code.co_name)
        trigger = af.external_trigger(name='stream_trigger')
        job_config = af.BaseJobConfig('local', 'cmd_line')
        job_config.job_name = 'test_cmd'
        with af.config(job_config):
            cmd_executor = af.user_define_operation(output_num=0,
                                                    executor=CmdExecutor(
                                                        cmd_line="echo 'hello world' && sleep {}".format(1)))
        af.user_define_control_dependency(src=cmd_executor, dependency=trigger, signal_key='key',
                                          signal_value='value', signal_name='name', condition=SignalCondition.NECESSARY
                                          , action=SignalAction.START, life=SignalLife.ONCE,
                                          value_condition=SignalValueCondition.UPDATE)
        workflow_id = af.submit_ai_flow()
        af.get_ai_flow_client().update_notification('key', 'value1')
        time.sleep(5)
        af.get_ai_flow_client().update_notification('key', 'value2')
        time.sleep(10)
        af.stop_execution_by_id(workflow_id)
        res = af.get_ai_flow_client().list_job(5, 0)
        self.assertEqual(3, len(res))

    def test_user_define_control_dependency_1(self):
        print(sys._getframe().f_code.co_name)
        trigger = af.external_trigger(name='stream_trigger')
        job_config = af.BaseJobConfig('local', 'cmd_line')
        job_config.job_name = 'test_cmd'
        with af.config(job_config):
            cmd_executor = af.user_define_operation(output_num=0,
                                                    executor=CmdExecutor(
                                                        cmd_line="echo 'hello world' && sleep {}".format(2)))
        af.user_define_control_dependency(src=cmd_executor, dependency=trigger, signal_key='key',
                                          signal_value='value', signal_name='name', condition=SignalCondition.NECESSARY
                                          , action=SignalAction.RESTART, life=SignalLife.ONCE,
                                          value_condition=SignalValueCondition.UPDATE)
        workflow_id = af.submit_ai_flow()
        af.get_ai_flow_client().update_notification('key', 'value1')
        time.sleep(5)
        af.get_ai_flow_client().update_notification('key', 'value2')
        time.sleep(10)
        af.stop_execution_by_id(workflow_id)
        res = af.get_ai_flow_client().list_job(5, 0)
        self.assertEqual(3, len(res))

    def test_stream_with_external_trigger_with_model_control(self):
        print(sys._getframe().f_code.co_name)
        trigger = af.external_trigger(name='stream_trigger')
        job_config = af.BaseJobConfig('local', 'cmd_line')
        job_config.job_name = 'test_cmd'
        with af.config(job_config):
            cmd_executor = af.user_define_operation(output_num=0,
                                                    executor=CmdExecutor(
                                                        cmd_line="echo 'hello world' && sleep {}".format(1)))
        af.model_version_control_dependency(src=cmd_executor, dependency=trigger, model_name='model')
        workflow_id = af.submit_ai_flow()
        af.get_ai_flow_client().update_notification('model', 'v1')
        time.sleep(5)
        af.get_ai_flow_client().update_notification('model', 'v2')
        time.sleep(10)
        af.stop_execution_by_id(workflow_id)
        res = af.get_ai_flow_client().list_job(5, 0)
        self.assertEqual(3, len(res))

    def test_project_register(self):
        print(sys._getframe().f_code.co_name)
        TestProject.build_ai_graph(1)
        af.register_example(name="a", support_type=af.ExampleSupportType.EXAMPLE_BOTH)
        w_id = af.submit_ai_flow()
        res = af.wait_workflow_execution_finished(w_id)
        self.assertEqual(0, res)
        e_meta = af.get_example_by_name("a")
        self.assertEqual("a", e_meta.name)

    def test_periodic_job(self):
        print(sys._getframe().f_code.co_name)
        periodic_config = PeriodicConfig(periodic_type='interval', args={'seconds': 5})
        job_config = af.BaseJobConfig(platform='local', engine='cmd_line')
        job_config.job_name = 'test_periodic'
        job_config.periodic_config = periodic_config
        with af.config(job_config):
            af.user_define_operation(executor=af.CmdExecutor(cmd_line="echo 'hello world!'"))
        workflow_id = af.submit_ai_flow()
        time.sleep(10)
        af.stop_execution_by_id(workflow_id)


if __name__ == '__main__':
    unittest.main()
