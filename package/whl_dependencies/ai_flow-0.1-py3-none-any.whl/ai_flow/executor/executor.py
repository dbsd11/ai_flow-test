from typing import Text, Union, List
from ai_flow.common.json_utils import Jsonable
from ai_flow.common.serialization_utils import serialize


class BaseExecutor(Jsonable):
    """
    Base class of executor.
    """
    def __init__(self, executor_type: Text, node_id: Text = None) -> None:
        super().__init__()
        self.executor_type = executor_type
        self.node_id = node_id

    def get_type(self) -> Text:
        return self.executor_type


class PythonObjectExecutor(BaseExecutor):
    """
    Python Object executor.
    """
    def __init__(self, python_object: object, node_id: Text = None) -> None:
        """
        Set the user defined python object as member variables.

        :param python_object: User defined python object.
        :param node_id: Id of node.
        """
        super().__init__("python_object", node_id)
        self.python_object: bytes = serialize(python_object)


class PythonFuncExecutor(BaseExecutor):
    """
    Python function executor.
    """
    def __init__(self, python_func: object, node_id: Text = None) -> None:
        """
        Set the user defined python function as member variables.

        :param python_func: User defined python function.
        :param node_id: Id of node.
        """
        super().__init__("python_func", node_id)
        self.python_func: bytes = serialize(python_func)


class CmdExecutor(BaseExecutor):
    """
    Command line executor.
    """
    def __init__(self, cmd_line: Union[Text, List[Text]], node_id: Text = None) -> None:
        """
        Set the user defined command line as member variables.

        :param cmd_line: User defined command line function
        :param node_id: Id of node.
        """
        super().__init__("cmd", node_id)
        self.cmd_line: Union[Text, List[Text]] = cmd_line
