from abc import ABCMeta, abstractmethod
import time


class BaseSignalStore(metaclass=ABCMeta):

    @abstractmethod
    def update(self, key, value):
        pass

    @abstractmethod
    def get(self, key):
        pass

    @abstractmethod
    def get_value_and_time(self, key):
        pass

    @abstractmethod
    def in_store(self, key)->bool:
        pass


class MemorySignalStore(BaseSignalStore):
    def __init__(self) -> None:
        self.store = {}

    def update(self, key, value):
        self.store[key] = (value, time.time())

    def get(self, key):
        if key in self.store:
            return self.store[key][0]
        else:
            return None

    def get_value_and_time(self, key):
        if key in self.store:
            return self.store[key]
        else:
            return None

    def in_store(self, key)->bool:
        return key in self.store
