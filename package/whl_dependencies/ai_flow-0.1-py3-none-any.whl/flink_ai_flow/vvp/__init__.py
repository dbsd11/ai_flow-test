from flink_ai_flow.vvp.vvp_restful_api import default_flink_image_info, default_resources,\
    default_flink_config, default_logging
