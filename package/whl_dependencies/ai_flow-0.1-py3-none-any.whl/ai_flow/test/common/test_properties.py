import unittest

from ai_flow.common.properties import Properties


class TestProperties(unittest.TestCase):

    def test_create_properties(self):
        print("\n")
        p = Properties(a="aa", b=['a', 'b'])
        self.assertEqual(p['a'], 'aa')


if __name__ == '__main__':
    unittest.main()
