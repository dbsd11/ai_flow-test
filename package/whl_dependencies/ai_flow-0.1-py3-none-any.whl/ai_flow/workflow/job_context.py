from typing import Dict, Text, Optional
from ai_flow.meta.job_meta import ExecutionMode
from ai_flow.common.json_utils import Jsonable
from ai_flow.project.project_config import ProjectConfig


class JobContext(Jsonable):
    def __init__(self, execution_mode: ExecutionMode = ExecutionMode.BATCH) -> None:
        super().__init__()
        self.execution_mode = execution_mode
        self.job_uuid = None
        self.job_name = None
        self.job_instance_id = None
        self.workflow_execution_id: int = None
        self.properties: Dict[Text, Jsonable] = {}
        self.project_config: ProjectConfig = None

    def get_execution_mode(self) -> ExecutionMode:
        return self.execution_mode

    def get_property(self, key: Text)->Optional[Jsonable]:
        if key in self.properties:
            return self.properties[key]
        else:
            return None

    def set_property(self, key: Text, value: Jsonable):
        self.properties[key] = value
