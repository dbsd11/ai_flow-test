from typing import Text

from ai_flow.common.json_utils import Jsonable


class ModelRelationMeta(Jsonable):
    def __init__(self,
                 name: Text,
                 project_id: int,
                 uuid: int = None):
        self.name = name
        self.project_id = project_id
        self.uuid = uuid

    def __str__(self):
        return '<\n' \
               'ModelRelation\n' \
               'uuid:{}\n' \
               'name:{},\n' \
               'project_id:{}\n' \
               '>'.format(
            self.uuid, self.name, self.project_id)


class ModelVersionRelationMeta(Jsonable):
    def __init__(self,
                 version: Text,
                 model_id: int,
                 workflow_execution_id: int):
        self.version = version
        self.model_id = model_id
        self.workflow_execution_id = workflow_execution_id

    def __str__(self):
        return '<\n' \
               'ModelVersionRelation\n' \
               'version:{},\n' \
               'model_id:{},\n' \
               'workflow_execution_id:{}\n' \
               '>'.format(self.version, self.model_id, self.workflow_execution_id)


def create_model_relation(name: Text,
                          project_id: int):
    return ModelRelationMeta(name=name, project_id=project_id)


def create_model_version_relation(version: Text,
                                  model_id: int,
                                  workflow_execution_id: int):
    return ModelVersionRelationMeta(version=version, model_id=model_id, workflow_execution_id=workflow_execution_id)
