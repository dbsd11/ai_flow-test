from ai_flow.common.properties import Properties, ExecuteProperties

Args = Properties
ExecuteArgs = ExecuteProperties
