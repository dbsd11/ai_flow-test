import os

main_class = 'com.apache.flink.ai.flow.FlinkJobMain'
jar_name = 'flink_ai_flow-1.0-SNAPSHOT.jar'
jar_path = os.path.dirname(os.path.abspath(__file__)) + '/flink_ai_flow-1.0-SNAPSHOT.jar'

py_main_file = os.path.dirname(os.path.abspath(__file__)) + '/pyflink/pyflink_job_main.py'
py_cluster_main_file = os.path.dirname(os.path.abspath(__file__)) + '/pyflink/pyflink_cluster_main.py'
