from ai_flow.client.ai_flow_client import get_ai_flow_client
from ai_flow.rest_endpoint.service.client.notification_client import Watcher


def update_notification(key: str, value: str):
    """
    Update given key and value of notification in Notification Service.

    :param key: Key of notification updated in Notification Service.
    :param value: Value of notification updated in Notification Service.
    :return: A single object of :py:class:`ai_flow.notification.entity.Notification`
    created in notification service.
    """
    get_ai_flow_client().update_notification(key=key, value=value)


def list_notifications(key: str, version: int = None) -> list:
    """
    List specific `key` or `version` notifications in Notification Service.

    :param key: Key of notification for listening.
    :param version: (Optional) Version of notification for listening.
    """
    return get_ai_flow_client().list_notifications(key, version)


def start_listen_notification(listener_name: str, key: str, watcher: Watcher, version=None):
    """
    Start listen specific `key` or `version` notifications in Notification Service.

    :param listener_name: Name of registered listener to listen notification.
    :param key: Key of notification for listening.
    :param watcher: Watcher instance for listening notification.
    :param version: (Optional) Version of notification for listening.
    """
    get_ai_flow_client().start_listen_notification(listener_name, key, watcher, version)


def stop_listen_notification(listener_name: str = None, key: str = None):
    """
    Stop listen specific `key` notifications in Notification Service.

    :param listener_name: Name of registered listener to listen notification.
    :param key: Key of notification for listening.
    """
    get_ai_flow_client().stop_listen_notification(listener_name, key)
