import psutil
from typing import List


def get_all_children_pids(current_pid=None) -> List:
    result = []
    if not psutil.pid_exists(current_pid):
        return result
    p = psutil.Process(current_pid)
    for pp in p.children():
        result.append(pp.pid)
        result.extend(get_all_children_pids(pp.pid))
    return result


