import unittest

from ai_flow.common import json_utils
from ai_flow.graph.node import BaseNode


class TestNode(unittest.TestCase):

    def test_json(self):
        node = BaseNode(name="a")
        json_text = json_utils.dumps(node)
        print(json_text)
        n2: BaseNode = json_utils.loads(json_text)
        self.assertEqual(node.name, n2.name)


if __name__ == '__main__':
    unittest.main()
