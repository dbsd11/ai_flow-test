import os
import threading
from abc import ABCMeta, abstractmethod

import grpc

from ai_flow.notification.entity.notification import Notification
from ai_flow.notification.service import AIFLOW_NOTIFICATION_TIMEOUT_SECONDS
from ai_flow.rest_endpoint.protobuf import notification_service_pb2_grpc
from ai_flow.rest_endpoint.protobuf.message_pb2 import Notification as ProtoNotification, Notifications
from ai_flow.rest_endpoint.protobuf.notification_service_pb2 import UpdateNotificationRequest, ListNotificationsRequest
from ai_flow.rest_endpoint.protobuf.notification_service_pb2_grpc import NotificationServiceStub
from ai_flow.rest_endpoint.service import stringValue, int32Value
from ai_flow.rest_endpoint.service.client.base_client import BaseClient
from ai_flow.rest_endpoint.service.util import _parse_response

NOTIFICATION_TIMEOUT_SECONDS = os.environ.get(AIFLOW_NOTIFICATION_TIMEOUT_SECONDS, 5)


class Watcher:
    __metaclass__ = ABCMeta

    def __init__(self):
        pass

    @abstractmethod
    def process(self, listener_name: str, notifications: list):
        pass


class NotificationClient(BaseClient):

    def __init__(self, server_uri):
        super(NotificationClient, self).__init__(server_uri)
        channel = grpc.insecure_channel(server_uri)
        self.notification_stub = notification_service_pb2_grpc.NotificationServiceStub(channel)
        self.threads = {}
        self.lock = threading.Lock()

    def update_notification(self, key: str, value: str) -> Notification:
        """
        Update given key and value of notification in Notification Service.

        :param key: Key of notification updated in Notification Service.
        :param value: Value of notification updated in Notification Service.
        :return: A single object of :py:class:`ai_flow.notification.entity.Notification`
        created in notification service.
         """
        request = UpdateNotificationRequest(
            notification=ProtoNotification(key=stringValue(key), value=stringValue(value)))
        response = self.notification_stub.updateNotification(request)
        notification_meta = Notification.from_proto(_parse_response(response, ProtoNotification()))
        return notification_meta

    def list_notifications(self, key: str, version: int = None) -> list:
        """
        List specific `key` or `version` notifications in Notification Service.

        :param key: Key of notification for listening.
        :param version: (Optional) Version of notification for listening.
        """
        request = ListNotificationsRequest(
            notification=ProtoNotification(key=stringValue(key), version=int32Value(version)))
        response = self.notification_stub.listNotifications(request)
        notifications = []
        for notification in _parse_response(response, Notifications()).notifications:
            notifications.append(Notification.from_proto(notification))
        return notifications

    def start_listen_notification(self, listener_name: str, key: str, watcher: Watcher, version: int = None):
        """
        Start listen specific `key` or `version` notifications in Notification Service.

        :param listener_name: Name of registered listener to listen notification.
        :param key: Key of notification for listening.
        :param watcher: Watcher instance for listening notification.
        :param version: (Optional) Version of notification for listening.
        """

        def list_notifications(stub: NotificationServiceStub, k: str, v: str, timeout_seconds: int = None):
            request = ListNotificationsRequest(
                notification=ProtoNotification(key=stringValue(k), version=int32Value(v)),
                timeout_seconds=timeout_seconds)
            response = stub.listNotifications(request)
            notifications = []
            for notification in _parse_response(response, Notifications()).notifications:
                notifications.append(Notification.from_proto(notification))
            return notifications

        def listen(stub, l, k, v, w):
            t = threading.current_thread()
            listen_version = v
            while getattr(t, '_flag', True):
                notifications = list_notifications(stub, k, listen_version, NOTIFICATION_TIMEOUT_SECONDS)
                if len(notifications) > 0:
                    w.process(l, notifications)
                    listen_version = notifications[len(notifications) - 1].version

        if self.threads.get((listener_name, key)) is None:
            thread = threading.Thread(target=listen,
                                      args=(self.notification_stub, listener_name, key, version, watcher))
            thread.start()
            self.lock.acquire()
            try:
                self.threads[listener_name, key] = thread
            finally:
                self.lock.release()

    def stop_listen_notification(self, listener_name: str = None, key: str = None):
        """
        Stop listen specific `key` notifications in Notification Service.

        :param listener_name: Name of registered listener to listen notification.
        :param key: Key of notification for listening.
        """
        if listener_name is None and key is None:
            for (k, v) in self.threads.items():
                thread = self.threads[k]
                thread._flag = False
                thread.join()
            self.threads.clear()
        elif listener_name is not None and key is not None:
            self.lock.acquire()
            try:
                if (listener_name, key) in self.threads:
                    thread = self.threads[listener_name, key]
                    thread._flag = False
                    thread.join()
                    del self.threads[listener_name, key]
            finally:
                self.lock.release()
