from typing import Text, List
from ai_flow.meta.model_meta import ModelMeta
from ai_flow.common.properties import ExecuteProperties
from ai_flow.executor.executor import BaseExecutor
from ai_flow.graph.ai_nodes.executable import ExecutableNode
from ai_flow.graph.channel import Channel, NoneChannel


class Trainer(ExecutableNode):

    def __init__(self,
                 name: Text,
                 executor: BaseExecutor,
                 output_model: ModelMeta,
                 base_model: ModelMeta = None,
                 properties: ExecuteProperties = None,
                 instance_id=None,
                 output_num=0) -> None:
        super().__init__(
            executor=executor,
            properties=properties,
            name=name,
            instance_id=instance_id,
            output_num=output_num)
        self.output_model = output_model
        self.from_model_version = base_model
