import time
import webbrowser
from subprocess import Popen
from typing import Text, List

from pyecharts import options
from pyecharts.charts import Bar, Line
from pyecharts.globals import ThemeType

from ai_flow.client.ai_flow_client import get_ai_flow_client
from ai_flow.common.path_util import get_file_dir
from ai_flow.common.properties import ExecuteProperties
from ai_flow.executor.executor import BaseExecutor
from ai_flow.graph.ai_nodes.executable import ExecutableNode
from ai_flow.graph.channel import Channel
from ai_flow.meta.metric_meta import MetricMeta, MetricType
from ai_flow.meta.model_meta import ModelMeta
from ai_flow.udf.function_context import FunctionContext
from python_ai_flow import Executor


class Visualizer(ExecutableNode):

    def __init__(self,
                 model: ModelMeta,
                 executor: BaseExecutor,
                 properties: ExecuteProperties = None,
                 name: Text = None,
                 instance_id: Text = None) -> None:
        super().__init__(executor=executor,
                         properties=properties,
                         name=name,
                         instance_id=instance_id,
                         output_num=0)
        self.model = model

    def outputs(self) -> List[Channel]:
        return [Channel(node_id=self.instance_id, port=0)]


class VisualizeExecutor(Executor):

    def __init__(self, model_meta) -> None:
        super().__init__()
        self._model_meta = model_meta

    def execute(self, function_context: FunctionContext, input_list: List):
        serving_model_version = get_ai_flow_client().get_serving_model_version(self._model_meta.name)
        metric_metas = get_ai_flow_client().get_model_metric_meta(model_name=self._model_meta.name,
                                                                  model_version=serving_model_version.version)
        metric_tags = []
        metric_paths = []
        model_metric_keys = []
        model_metric_values = []
        dataset_metric_keys = []
        dataset_metric_values = []
        if isinstance(metric_metas[2], MetricMeta):
            metric_tags.append(metric_metas[2].tags)
            metric_paths.append(metric_metas[2].uri)
            metric_summaries = get_ai_flow_client().get_metric_summary(metric_id=metric_metas[2].uuid)
            if metric_summaries[2] is not None:
                for metric_summary in metric_summaries[2]:
                    if metric_metas[2].metric_type == MetricType.MODEL:
                        model_metric_keys.append(metric_summary.metric_key)
                        model_metric_values.append(metric_summary.metric_value)
                    elif metric_metas[2].metric_type == MetricType.DATASET:
                        dataset_metric_keys.append(metric_summary.metric_key)
                        dataset_metric_values.append(metric_summary.metric_value)
        elif isinstance(metric_metas[2], List):
            for metric_meta in metric_metas[2]:
                metric_tags.append(metric_meta.tags)
                metric_paths.append(metric_meta.uri)
                metric_summaries = get_ai_flow_client().get_metric_summary(metric_id=metric_meta.uuid)
                if metric_summaries[2] is not None:
                    for metric_summary in metric_summaries[2]:
                        if metric_meta.metric_type == MetricType.MODEL:
                            model_metric_keys.append(metric_summary.metric_key)
                            model_metric_values.append(metric_summary.metric_value)
                        elif metric_meta.metric_type == MetricType.DATASET:
                            dataset_metric_keys.append(metric_summary.metric_key)
                            dataset_metric_values.append(metric_summary.metric_value)

        if 'sklearn' in metric_tags:
            if len(model_metric_keys) != 0:
                (
                    Bar(init_opts=options.InitOpts(theme=ThemeType.MACARONS))
                        .add_xaxis(model_metric_keys)
                        .add_yaxis('summary', model_metric_values)
                        .set_global_opts(
                        title_opts=options.TitleOpts(title='{} Metric Dashboard'.format(MetricType.MODEL.lower())),
                        xaxis_opts=options.AxisOpts(name='metric_key'),
                        yaxis_opts=options.AxisOpts(name='metric_value'),
                        toolbox_opts=options.ToolboxOpts(),
                        legend_opts=options.LegendOpts(is_show=False))
                        .render("{}/{}_metric_dashboard.html".format(get_file_dir(__file__), MetricType.MODEL.lower()))
                )
                webbrowser.open_new(
                    'file://{}/{}_metric_dashboard.html'.format(get_file_dir(__file__), MetricType.MODEL.lower()))

            if len(dataset_metric_keys) != 0:
                (
                    Line(init_opts=options.InitOpts(theme=ThemeType.LIGHT))
                        .add_xaxis(dataset_metric_keys)
                        .add_yaxis('summary', dataset_metric_values)
                        .set_global_opts(
                        title_opts=options.TitleOpts(title='{} Metric Dashboard'.format(MetricType.DATASET.lower())),
                        xaxis_opts=options.AxisOpts(name='metric_key'),
                        yaxis_opts=options.AxisOpts(name='metric_value'),
                        toolbox_opts=options.ToolboxOpts(),
                        legend_opts=options.LegendOpts(is_show=False))
                        .render(
                        "{}/{}_metric_dashboard.html".format(get_file_dir(__file__), MetricType.DATASET.lower()))
                )
                webbrowser.open_new(
                    'file://{}/{}_metric_dashboard.html'.format(get_file_dir(__file__), MetricType.DATASET.lower()))
        elif 'tensorflow' in metric_tags:
            Popen('tensorboard --logdir {}'.format(metric_paths[0]), shell=True)
            time.sleep(5)
            webbrowser.open_new('http://localhost:6006')
