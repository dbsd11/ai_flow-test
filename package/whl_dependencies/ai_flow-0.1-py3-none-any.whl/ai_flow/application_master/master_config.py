from ai_flow.common.configuration import AIFlowConfiguration
from enum import Enum
from typing import Text


class DBType(str, Enum):
    SQLITE = "sql_lite"
    MYSQL = "mysql"

    @staticmethod
    def value_of(db_type):
        if db_type in ('SQL_LITE', 'sql_lite'):
            return DBType.SQLITE
        elif db_type in ('MYSQL', 'mysql'):
            return DBType.MYSQL
        else:
            raise NotImplementedError


class MasterConfig(AIFlowConfiguration):
    def get_sql_lite_db_file(self):
        db_uri = self.get_db_uri()
        return db_uri[10:]

    def get_master_port(self):
        return self["master_port"]

    def get_db_uri(self):
        return self["db_uri"]

    def get_db_type(self) -> DBType:
        return DBType.value_of(self["db_type"])

    def set_master_port(self, value):
        self["master_port"] = value

    def set_db_uri(self, db_type: DBType, uri: Text):
        self["db_type"] = db_type.value
        self["db_uri"] = uri
