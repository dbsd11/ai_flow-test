import pickle

_BYTES_ENCODE = "ISO-8859-1"


def serialize(o: object) -> bytes:
    return pickle.dumps(o)


def deserialize(s: bytes) -> object:
    return pickle.loads(s)
