from typing import Text
from ai_flow.graph.node import BaseNode
from ai_flow.workflow.job_context import JobContext
from ai_flow.meta.job_meta import State
from ai_flow.workflow.job_config import BaseJobConfig


class BaseJob(BaseNode):
    """
    A BaseJob contains the common information of a ai flow job. Users can implement custom jobs by adding other
    execution information for a specific engine and platform.
    """
    def __init__(self, job_context: JobContext, job_config: BaseJobConfig) -> None:
        """

        :param job_context:
        :param job_config:
        """
        super().__init__()
        self.job_context: JobContext = job_context
        self.job_config = job_config
        self.platform = job_config.platform
        self.exec_engine = job_config.engine
        self.status = State.INIT
        self.start_time = None
        self.end_time = None
        self.uuid = None
        self.job_name: Text = None

