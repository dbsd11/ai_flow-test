
def str_to_bool(data)->bool:
    return data == str(True)
