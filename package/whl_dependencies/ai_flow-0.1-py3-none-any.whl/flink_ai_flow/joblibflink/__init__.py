"""
Joblib Flink backend is extension for Joblib tools, which makes Joblib running on Flink parallelly.
"""


# Register Joblib Flink Parallel backend factory.
def register_flink():
    """
    Register Flink backend into Joblib called with parallel_backend('flink').
    """
    try:
        from .flink_backend import register
        register()
    except ImportError:
        msg = ("To use the flink distributed backend you must install the pyflink and packages."
               "Try to execute `python -m pip install apache-flink`."
               "See https://ci.apache.org/projects/flink for more information.")
        raise ImportError(msg)


__all__ = ['register_flink']
