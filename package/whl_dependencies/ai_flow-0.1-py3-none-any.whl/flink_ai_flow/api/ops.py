from typing import Text
from ai_flow.api.ops import user_define_operation
from ai_flow.common.args import ExecuteArgs
from ai_flow.graph.channel import NoneChannel
from flink_ai_flow.flink_executor import FlinkJavaExecutor


def vvp_job(executor: FlinkJavaExecutor,
            exec_args: ExecuteArgs = None,
            name: Text = None)->NoneChannel:
    return user_define_operation(executor=executor,
                                 output_num=0,
                                 input_data_list=None,
                                 exec_args=exec_args,
                                 name=name)
