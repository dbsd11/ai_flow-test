import unittest

from ai_flow import AIFlowMaster
from ai_flow.api.configuration import project_config
from ai_flow.test import test_util


class TestConfiguration(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        config_file = test_util.get_master_config_file()
        cls.master = AIFlowMaster(config_file=config_file)
        cls.master.start()
        test_util.set_project_config(__file__)

    @classmethod
    def tearDownClass(cls) -> None:
        cls.master.stop()

    def tearDown(self):
        TestConfiguration.master._clear_db()

    def test_load_configuration(self):
        config = project_config()
        self.assertEqual(config.get_master_uri(), 'localhost:50051')


if __name__ == '__main__':
    unittest.main()
