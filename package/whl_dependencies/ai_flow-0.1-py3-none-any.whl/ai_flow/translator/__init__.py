from ai_flow.translator.base_translator import register_job_generator
# from ai_flow.translator.cmd_job_generator import CMDJobGenerator
#
# register_job_generator(CMDJobGenerator(platform="local"))
# register_job_generator(CMDJobGenerator(platform="k8s"))

