from typing import Text
from enum import Enum
from ai_flow.common.json_utils import Jsonable


class Edge(Jsonable):
    """ the edge connect tow node"""

    def __init__(self,
                 target_node_id: Text,
                 source_node_id: Text,
                 ) -> None:
        """

        :param target_node_id: the node dependent the other node output id
        :param source_node_id: the node id
        """
        super().__init__()
        if target_node_id is None or source_node_id is None:
            raise Exception('target node id and source node id can not None!')
        self.target_node_id = target_node_id
        self.source_node_id = source_node_id

    def __eq__(self, o: object) -> bool:
        if isinstance(o, Edge):
            return self.source_node_id == o.source_node_id and self.target_node_id == o.target_node_id
        else:
            return False

    def __ne__(self, o: object) -> bool:
        return not self.__eq__(0)


class DataEdge(Edge):
    def __init__(self,
                 target_node_id: Text,
                 source_node_id: Text,
                 port: int = 0,
                 data_config: Jsonable = None) -> None:
        super().__init__(source_node_id=source_node_id, target_node_id=target_node_id)
        self.port = port
        self.data_config = data_config

    def __eq__(self, o: object) -> bool:
        if isinstance(o, DataEdge):
            return self.source_node_id == o.source_node_id \
                   and self.target_node_id == o.target_node_id \
                   and self.port == o.port
        else:
            return False

    def __ne__(self, o: object) -> bool:
        return not self.__eq__(0)


class SignalCondition(str, Enum):
    SUFFICIENT = "SUFFICIENT"
    NECESSARY = "NECESSARY"


class SignalAction(str, Enum):
    """
    START: start init job
    RESTART: start init job or stop running job and start the job
    """
    START = "START"
    RESTART = "RESTART"


class SignalLife(str, Enum):
    """
    ONCE: the signal value will be used only once
    REPEATED: the signal value will be used repeated
    """
    ONCE = "ONCE"
    REPEATED = "REPEATED"


class SignalValueCondition(str, Enum):
    """
    EQUAL: the condition that notification service updates a value which equals to the signal value
    UPDATE: the condition that notification service has a update operation on the signal key which signal
            value belongs to
    """
    EQUAL = "EQUAL"
    UPDATE = "UPDATE"


class SignalConfig(Jsonable):
    def __init__(self,
                 signal_key: Text,
                 signal_value: Text,
                 signal_name: Text = None,
                 condition: SignalCondition = SignalCondition.NECESSARY,
                 action: SignalAction = SignalAction.START,
                 life: SignalLife = SignalLife.ONCE,
                 value_condition: SignalValueCondition = SignalValueCondition.EQUAL
                 ):
        self.signal_name = signal_name
        self.signal_key = signal_key
        self.signal_value = signal_value
        self.condition = condition
        self.action = action
        self.life = life
        self.value_condition = value_condition


def generate_job_status_key(target_id) -> str:
    return str(target_id) + ".job_status"


class ControlEdge(Edge):

    def generate_signal_config(self) -> SignalConfig:
        return SignalConfig(signal_key=generate_job_status_key(self.target_node_id), signal_value="FINISHED")


class UserDefineControlEdge(ControlEdge):

    def __init__(self, target_node_id: Text,
                 source_node_id: Text,
                 signal_key: Text,
                 signal_value: Text,
                 signal_name: Text = None,
                 condition: SignalCondition = SignalCondition.NECESSARY,
                 action: SignalAction = SignalAction.START,
                 life: SignalLife = SignalLife.ONCE,
                 value_condition: SignalValueCondition = SignalValueCondition.EQUAL
                 ) -> None:
        super().__init__(target_node_id, source_node_id)
        self.signal_key = signal_key
        self.signal_value = signal_value
        self.signal_name = signal_name
        self.condition = condition
        self.action = action
        self.life = life
        self.value_condition = value_condition

    def generate_signal_config(self) -> SignalConfig:
        return SignalConfig(signal_key=self.signal_key,
                            signal_value=self.signal_value,
                            signal_name=self.signal_name,
                            condition=self.condition,
                            action=self.action,
                            life=self.life,
                            value_condition=self.value_condition)


class JobControlEdge(Edge):
    def __init__(self,
                 target_node_id: Text,
                 source_node_id: Text = None,
                 signal_config: SignalConfig = None,
                 ) -> None:
        super().__init__(target_node_id, source_node_id)
        if signal_config is None:
            self.signal = SignalConfig(signal_key=generate_job_status_key(target_node_id), signal_value="FINISHED")
        else:
            self.signal = signal_config


def control_edge_to_job_edge(control_edge: ControlEdge) -> JobControlEdge:
    return JobControlEdge(source_node_id=control_edge.source_node_id,
                          target_node_id=control_edge.target_node_id,
                          signal_config=control_edge.generate_signal_config())


class StartBeforeControlEdge(ControlEdge):

    def generate_signal_config(self) -> SignalConfig:
        return SignalConfig(signal_key=generate_job_status_key(self.target_node_id), signal_value="STARTING")


class StopBeforeControlEdge(ControlEdge):
    pass


class ModelVersionControlEdge(ControlEdge):
    def __init__(self, model_name: Text,
                 target_node_id: Text,
                 source_node_id: Text = None) -> None:
        super().__init__(target_node_id, source_node_id)
        self.model_name = model_name

    def generate_signal_config(self) -> SignalConfig:
        return SignalConfig(signal_name='model',
                            signal_key=self.model_name,
                            signal_value="*",
                            action=SignalAction.RESTART,
                            life=SignalLife.ONCE,
                            value_condition=SignalValueCondition.UPDATE,
                            condition=SignalCondition.SUFFICIENT)


class ExampleControlEdge(ControlEdge):
    def __init__(self, example_name: Text,
                 target_node_id: Text,
                 source_node_id: Text = None) -> None:
        super().__init__(target_node_id, source_node_id)
        self.example_name = example_name

    def generate_signal_config(self) -> SignalConfig:
        return SignalConfig(signal_key="example." + self.example_name, signal_value="created")
